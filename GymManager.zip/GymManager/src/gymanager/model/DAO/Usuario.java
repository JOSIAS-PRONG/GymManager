package gymanager.model.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.sql.Timestamp;

public class Usuario {


    private String nome, email, observacao;
         private int idade;
         private String cpf; 


    public Usuario(String nome, String email,String observacao, int idade, String cpf) {
        this.nome = nome;
        this.email = email;
        this.observacao = observacao;
       
        this.idade = idade;
        this.cpf = cpf;
    }
    public void cadastrarUsuario(String nome, String email, int idade, String cpf, String observacao, String plano, String senha, String pagamento, Date dataAtual) {
        Connection conexao = null;
             Timestamp dataModificada = new Timestamp(dataAtual.getTime());

        try {
            conexao = Conexao.obterConexao();

            String sql = "INSERT INTO cliente (nome_cliente, email_cliente, idade_cliente, cpf_cliente, observacao, plano, senha, pagamento, dataEntrada_cliente) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            try (PreparedStatement preparedStatement = conexao.prepareStatement(sql)) {
                
                
                
                preparedStatement.setString(1, nome);
                preparedStatement.setString(2, email);
                preparedStatement.setInt(3, idade);
                preparedStatement.setString(4, cpf);
                preparedStatement.setString(5, observacao);
                preparedStatement.setString(6, plano);
                preparedStatement.setString(7, senha);
                 preparedStatement.setString(8, pagamento);
               preparedStatement.setTimestamp(9, dataModificada);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao cadastrar usuário no banco " + ex.getMessage());
        } /*finally {
            try {
                if (conexao != null) {
                    Conexao.fecharConexao();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar a conexão " + ex.getMessage());
            }
        }
        */
    }
    
    
    
     public boolean verificarUsuario(String cpf) {
        // Converta o long para String
        //String cpfString = String.valueOf(cpf);

        // Lógica para verificar se o usuário existe no banco de dados
        Connection conexao = null;

        try {
            conexao = Conexao.obterConexao(); // Obtém a conexão usando a classe de conexão

            // Consulta SQL parametrizada para verificar o usuário com o CPF fornecido
            String sql = "SELECT * FROM cliente WHERE cpf_cliente = ?";

            try (PreparedStatement preparedStatement = conexao.prepareStatement(sql)) {
                preparedStatement.setString(1, cpf);

                // Execute a consulta
                try (ResultSet resultado = preparedStatement.executeQuery()) {
                    // Se houver pelo menos uma linha no resultado, o usuário existe
                    return resultado.next();
                }
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao acessar o banco " + ex.getMessage());
            return false;
        } 
        /*
        finally {
            try {
                if (conexao != null) {
                    Conexao.fecharConexao(); // Feche a conexão usando a classe de conexão
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar a conexão " + ex.getMessage());
            }
        }
        */
    }
     
public static List<String> pesquisarCliente(String pesquisa) {
    Connection conexao = null;
    List<String> resultados = new ArrayList<>();

    try {
        conexao = Conexao.obterConexao(); // Obtém a conexão usando a classe de conexão

        // Consulta SQL parametrizada para pesquisar funcionários pelo nome
        String sql = "SELECT nome_cliente, email_cliente, pagamento FROM cliente WHERE nome_cliente LIKE ?";

        try (PreparedStatement preparedStatement = conexao.prepareStatement(sql)) {
            preparedStatement.setString(1, "%" + pesquisa + "%");

            // Execute a consulta
            try (ResultSet resultado = preparedStatement.executeQuery()) {
                // Iterar sobre os resultados e adicionar informações à lista
                while (resultado.next()) {
                    String nome = resultado.getString("nome_cliente");
                    String email = resultado.getString("email_cliente");
                      String pagamento = resultado.getString("pagamento");

                    StringBuilder infoFuncionario = new StringBuilder();
                    infoFuncionario.append("Nome: ").append(nome).append(", Email: ").append(email)
                            .append(", Pagemento: ").append(pagamento);


                    resultados.add(infoFuncionario.toString());
                }
            }
        }
    } catch (SQLException ex) {
        System.out.println("Erro ao acessar o banco " + ex.getMessage());
    } /*finally {
        try {
            if (conexao != null) {
                Conexao.fecharConexao(); // Feche a conexão usando a classe de conexão
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao fechar a conexão " + ex.getMessage());
        }
    }*/

    return resultados;
}

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
}
