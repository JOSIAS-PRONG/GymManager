package gymanager.model.DAO;

//import  gymanager.model.DAO.interfaces.funcionariosInterface;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.sql.Timestamp;
import java.util.List;


public class FuncionariosDAO{
    private String nome, email, horario, observacao;
    private int idade;
    private double cpf;

    public FuncionariosDAO(String nome, int idade, String email, String observacao, String horario, double cpf) {
        this.nome = nome;
        this.idade = idade;
        this.email = email;
        this.horario = horario;
        this.observacao = observacao;
    }
//verificar se o funcionário está no sistema para realizar o login
    public static boolean autenticarFuncionario(String email, String senha) {
        Connection conexao = null;

        try {
            conexao = Conexao.obterConexao(); // Obtém a conexão usando a classe de conexão

            // Consulta SQL para verificar usuário com o email e senha fornecidos
            String sql = "SELECT * FROM funcionario WHERE email_funcionario = ? AND senha = ?";

            try (PreparedStatement preparedStatement = conexao.prepareStatement(sql)) {
                preparedStatement.setString(1, email);
                preparedStatement.setString(2, senha);

                // Executar a consulta
                try (ResultSet resultado = preparedStatement.executeQuery()) {
                    // Se houver pelo menos uma linha no resultado, o usuário existe
                    return resultado.next();
                }
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao acessar o banco " + ex.getMessage());
            return false;
        } 
        /*finally {
            try {
                if (conexao != null) {
                    Conexao.fecharConexao(); // Feche a conexão usando a classe de conexão
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar a conexão " + ex.getMessage());
            }
        }*/
    }
    
    //realizar a verificação do CPF do funcionário para ver se ele já não está cadastrado
    public static boolean autenticarExistenciaFuncionario(String cpf){
        
        Connection conexao = null;
        
          try {
            conexao = Conexao.obterConexao(); // Obtém a conexão usando a classe de conexão
            
            // Consulta SQL parametrizada para selecionar usuário com o email e senha fornecidos
            String sql = "SELECT * FROM funcionario WHERE cpf_funcionario = ?";

            try (PreparedStatement preparedStatement = conexao.prepareStatement(sql)) {
                preparedStatement.setString(1, cpf);
              

                // Executar a consulta
                try (ResultSet resultado = preparedStatement.executeQuery()) {
                    // Se houver pelo menos uma linha no resultado, o usuário existe
                    return resultado.next();
                }
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao acessar o banco " + ex.getMessage());
            return false;
        } /*finally {
            try {
                if (conexao != null) {
                    Conexao.fecharConexao(); // Feche a conexão usando a classe de conexão
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar a conexão " + ex.getMessage());
            }
        } */
        
        

    }
    public static void cadastrarFuncionario(String nome, String email, int idade, String cpf, String observacao, String senha, Date data) {
        Connection conexao = null;
        Timestamp dataModificada = new Timestamp(data.getTime());
        try {
            conexao = Conexao.obterConexao();

            String sql = "INSERT INTO funcionario (nome_funcionario, email_funcionario, idade_funcionario, cpf_funcionario, observacao, senha, dataEntrada_funcionario) VALUES (?, ?, ?, ?, ?, ?, ?)";

            try (PreparedStatement preparedStatement = conexao.prepareStatement(sql)) {
                preparedStatement.setString(1, nome);
                preparedStatement.setString(2, email);
                preparedStatement.setInt(3, idade);
                preparedStatement.setString(4, cpf);
                preparedStatement.setString(5, observacao);
                preparedStatement.setString(6, senha);
                preparedStatement.setTimestamp(7, dataModificada);
                
                preparedStatement.executeUpdate();
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao cadastrar funcionário no banco " + ex.getMessage());
        } /*finally {
            try {
                if (conexao != null) {
                    Conexao.fecharConexao();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar a conexão " + ex.getMessage());
            }
        }
        */
    }
    
    

 
        public static List<String> pesquisarFuncionario(String pesquisa) {
             Connection conexao = null;
                  List<String> resultados = new ArrayList<>();

    try {
        conexao = Conexao.obterConexao(); // Obtém a conexão usando a classe de conexão

        // Consulta SQL parametrizada para pesquisar funcionários pelo nome
        String sql = "SELECT nome_funcionario, email_funcionario, dataEntrada_funcionario FROM funcionario WHERE nome_funcionario LIKE ?";

        try (PreparedStatement preparedStatement = conexao.prepareStatement(sql)) {
            preparedStatement.setString(1, "%" + pesquisa + "%");

            // Execute a consulta
            try (ResultSet resultado = preparedStatement.executeQuery()) {
                // Iterar sobre os resultados e adicionar informações à lista
                while (resultado.next()) {
                    String nome = resultado.getString("nome_funcionario");
                    String email = resultado.getString("email_funcionario");
                    String data = resultado.getString("dataEntrada_funcionario");
                    
           

                    StringBuilder infoFuncionario = new StringBuilder();
                    infoFuncionario.append("Nome: ").append(nome).append(", Email: ").append(", Email: ").append(email);


                    resultados.add(infoFuncionario.toString());
                }
            }
        }
    } catch (SQLException ex) {
        System.out.println("Erro ao acessar o banco " + ex.getMessage());
    } /*finally {
        try {
            if (conexao != null) {
                Conexao.fecharConexao(); // Feche a conexão usando a classe de conexão
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao fechar a conexão " + ex.getMessage());
        }
    }*/

    return resultados;
}

    // Métodos getters e setters...

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public double getCpf() {
        return cpf;
    }

    public void setCpf(double cpf) {
        this.cpf = cpf;
    }
}
