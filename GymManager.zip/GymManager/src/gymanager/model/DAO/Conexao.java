package gymanager.model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    private static Connection conexao;
    
    public static Connection obterConexao() throws SQLException {
        if (conexao == null) {
            try {
                String jdbcUrl = "jdbc:mysql://localhost:3306/gym";
                String usuario = "root";
                String senha = "josias3455";
                Class.forName("com.mysql.cj.jdbc.Driver"); // Adicione essa linha para carregar o driver

                conexao = DriverManager.getConnection(jdbcUrl, usuario, senha);
            }catch (ClassNotFoundException e) {
                // Trate a exceção ou relance-a, dependendo do seu caso
                System.out.println("Erro ao carregar o driver: " + e.getMessage());
            }
        }
        
        return conexao;
    }
    
    public static void fecharConexao() throws SQLException {
        if (conexao != null && !conexao.isClosed()) {
            conexao.close();
        }
    }
}
