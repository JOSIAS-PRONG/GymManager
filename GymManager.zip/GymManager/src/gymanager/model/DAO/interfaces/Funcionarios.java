/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gymanager.model.DAO.interfaces;
//import gymanager.model.DAO.Funcionarios;
import gymanager.view.MainFrame;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import gymanager.model.DAO.FuncionariosDAO;
/**
 *
 * @author Máquina Virtual
 */
public class Funcionarios {
    
    
        
    public static boolean login(String email, String senha){
        if(FuncionariosDAO.autenticarFuncionario(email, senha)){
            //fazer a verificacao com o banco de dados aqui
            JOptionPane.showMessageDialog(null, "Bem vindo ao GymManager");
            MainFrame telaprincipal = new MainFrame();
            telaprincipal.setVisible(true);
            return true;
            
        }
    else{
             JOptionPane.showMessageDialog(null, "Esse usuário não existe no sistema do GymManager");
            return false;
        }
    }
    
    
public static void cadastrar(String nome, String email, String cpf, String observacao, int idade, String senha, Date dataNascimento){
        
        //fazer verificacao com o banco de dados aqui
 try {
    //Funcionarios funcionario = new Funcionarios(nomeT, idade, email, hora, observacao, cpf);

    if (FuncionariosDAO.autenticarExistenciaFuncionario(cpf)) {
        // Usuário já existe no sistema...
        JOptionPane.showMessageDialog(null, "Funcionário " + nome + " já está cadastrado no sistema!");
      
    }else{
        
        FuncionariosDAO.cadastrarFuncionario(nome,email,idade,cpf, observacao, senha, dataNascimento);
         JOptionPane.showMessageDialog(null, "O funcionário " + nome + " foi cadastrado com sucesso no sistema!");
      
        
    }
} catch (NumberFormatException e) {
    // Trate a exceção se a entrada não for numérica
    System.out.println("Erro ao converter um valor numérico: " + e.getMessage());
}   
        
}
    
    
}
