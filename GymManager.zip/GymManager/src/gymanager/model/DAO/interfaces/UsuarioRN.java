/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gymanager.model.DAO.interfaces;

import gymanager.model.DAO.Usuario;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author Máquina Virtual
 */
public class UsuarioRN {
    public static void cadastro(String nome, String email, String cpf, int idade, String observacao, String senha, boolean corporativo, boolean mensalidade){
           Usuario usuario = new Usuario(nome, email, observacao, idade, cpf);

            if (usuario.verificarUsuario(cpf)) {
                // Usuário já existe no sistema...
                
                
                JOptionPane.showMessageDialog(null, "O cliente " + nome + " já está cadastrado no sistema!");

            }else{
                try{
                     Date dataNascimento = new Date();
                    if(corporativo){
                        if(mensalidade){
                              usuario.cadastrarUsuario(nome, email, idade, cpf, observacao, "corporativo", senha, "Sim", dataNascimento);
                              //sucesso
                               JOptionPane.showMessageDialog(null, "O Cliente foi cadastrado com sucesso no sistema! ");
                              
                        }else{
                              usuario.cadastrarUsuario(nome, email, idade, cpf, observacao, "corporativo", senha, "Nao", dataNascimento);
                              //sucesso
                               JOptionPane.showMessageDialog(null, "O Cliente foi cadastrado com sucesso no sistema! ");
                         
                        }
                        
                    }else{
                        if(mensalidade){
                             usuario.cadastrarUsuario(nome, email, idade, cpf, observacao, "normal", senha, "Sim", dataNascimento);
                             //sucesso
                               JOptionPane.showMessageDialog(null, "O Cliente foi cadastrado com sucesso no sistema! ");
                         
                        }else{
                              usuario.cadastrarUsuario(nome, email, idade, cpf, observacao, "normal", senha, "Nao", dataNascimento);
                              //sucesso
                               JOptionPane.showMessageDialog(null, "O Cliente foi cadastrado com sucesso no sistema! ");
                         
                      
                        }
                        
                    }
                 
                 
                }catch(Exception e){
                    System.out.println("erro no bagulho: " + e.getMessage());
                }
                
                
                
                
                //realizar cadastro
            }
        };
    //A pesquisa de usuários é feita diretamente na interface para que ela possa alterar os componentes diretamente
        
    }

