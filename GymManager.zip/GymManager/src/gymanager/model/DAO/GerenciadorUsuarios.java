package gymanager.model.DAO;

public class GerenciadorUsuarios {
   private String nome, email, horario, observacao;
        private int idade;
        private double cpf; 
   

    public GerenciadorUsuarios(int idade, String nome, String email, String horario, String observacao, double cpf) {
    this.nome = nome;
    this.email = email;
    this.horario = horario;
    this.observacao = observacao;
    this.idade = idade;
    this.cpf = cpf;
    }
   
    public void adicionarUsuario() {
    }

    public void editarUsuario() {
        //Vai ser implementado 
    }

    public void excluirUsuario() {
    }

    public void verUsuarios() {
    }
}
